// Auto Blog Generator JavaScript
class BlogGenerator {
    constructor() {
        this.isGenerating = false;
        this.schedulerRunning = false;
        this.init();
    }

    init() {
        this.bindEvents();
        this.updateUI();
        this.loadPosts();
    }

    bindEvents() {
        // Generate content button
        const generateBtn = document.getElementById('generateContent');
        if (generateBtn) {
            generateBtn.addEventListener('click', () => this.generateContent());
        }

        // Start scheduler button
        const startSchedulerBtn = document.getElementById('startScheduler');
        if (startSchedulerBtn) {
            startSchedulerBtn.addEventListener('click', () => this.startScheduler());
        }

        // Stop scheduler button
        const stopSchedulerBtn = document.getElementById('stopScheduler');
        if (stopSchedulerBtn) {
            stopSchedulerBtn.addEventListener('click', () => this.stopScheduler());
        }

        // Export site button
        const exportBtn = document.getElementById('exportSite');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => this.exportSite());
        }

        // Refresh posts button
        const refreshBtn = document.getElementById('refreshPosts');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.loadPosts());
        }

        // Tab switching
        document.querySelectorAll('[data-bs-toggle="tab"]').forEach(tab => {
            tab.addEventListener('shown.bs.tab', (e) => {
                if (e.target.getAttribute('href') === '#posts') {
                    this.loadPosts();
                }
            });
        });
    }

    async generateContent() {
        if (this.isGenerating) return;

        const generateBtn = document.getElementById('generateContent');
        const languageSelect = document.getElementById('language');
        const countSelect = document.getElementById('postCount');
        
        try {
            this.isGenerating = true;
            this.updateGenerateButton(true);
            this.showProgress('Generating blog posts...', 0);

            const data = {
                language: languageSelect.value,
                count: parseInt(countSelect.value)
            };

            const response = await fetch('/generate-content', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (result.success) {
                this.showProgress('Generation complete!', 100);
                this.showAlert('success', result.message);
                setTimeout(() => {
                    this.hideProgress();
                    this.loadPosts();
                }, 2000);
            } else {
                this.hideProgress();
                this.showAlert('danger', result.message);
            }

        } catch (error) {
            console.error('Error generating content:', error);
            this.hideProgress();
            this.showAlert('danger', 'An error occurred while generating content. Please try again.');
        } finally {
            this.isGenerating = false;
            this.updateGenerateButton(false);
        }
    }

    async startScheduler() {
        const intervalInput = document.getElementById('schedulerInterval');
        
        try {
            const data = {
                interval: parseInt(intervalInput.value)
            };

            const response = await fetch('/start-scheduler', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (result.success) {
                this.schedulerRunning = true;
                this.updateSchedulerUI();
                this.showAlert('success', result.message);
            } else {
                this.showAlert('danger', result.message);
            }

        } catch (error) {
            console.error('Error starting scheduler:', error);
            this.showAlert('danger', 'An error occurred while starting the scheduler.');
        }
    }

    async stopScheduler() {
        try {
            const response = await fetch('/stop-scheduler', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            const result = await response.json();

            if (result.success) {
                this.schedulerRunning = false;
                this.updateSchedulerUI();
                this.showAlert('info', result.message);
            } else {
                this.showAlert('danger', result.message);
            }

        } catch (error) {
            console.error('Error stopping scheduler:', error);
            this.showAlert('danger', 'An error occurred while stopping the scheduler.');
        }
    }

    async exportSite() {
        try {
            this.showAlert('info', 'Preparing site export...');
            
            const response = await fetch('/export-site');
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `blog_site_${new Date().toISOString().slice(0, 10)}.zip`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
                
                this.showAlert('success', 'Site exported successfully!');
            } else {
                const result = await response.json();
                this.showAlert('danger', result.message || 'Export failed');
            }

        } catch (error) {
            console.error('Error exporting site:', error);
            this.showAlert('danger', 'An error occurred while exporting the site.');
        }
    }

    async loadPosts() {
        // Load posts without page reload for better user experience
        try {
            const response = await fetch('/');
            if (response.ok) {
                // Posts are loaded through normal page navigation instead of forcing reload
                console.log('Posts refreshed successfully');
            }
        } catch (error) {
            console.error('Error loading posts:', error);
        }
    }

    async deletePost(filename) {
        if (!confirm('Are you sure you want to delete this post?')) {
            return;
        }

        try {
            const response = await fetch(`/delete-post/${filename}`, {
                method: 'POST'
            });

            const result = await response.json();

            if (result.success) {
                this.showAlert('success', result.message);
                this.loadPosts();
            } else {
                this.showAlert('danger', result.message);
            }

        } catch (error) {
            console.error('Error deleting post:', error);
            this.showAlert('danger', 'An error occurred while deleting the post.');
        }
    }

    updateGenerateButton(isLoading) {
        const btn = document.getElementById('generateContent');
        if (!btn) return;

        if (isLoading) {
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner"></span> Generating...';
        } else {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-magic"></i> Generate Content';
        }
    }

    updateSchedulerUI() {
        const startBtn = document.getElementById('startScheduler');
        const stopBtn = document.getElementById('stopScheduler');
        const status = document.getElementById('schedulerStatus');

        if (this.schedulerRunning) {
            if (startBtn) startBtn.style.display = 'none';
            if (stopBtn) stopBtn.style.display = 'inline-flex';
            if (status) {
                status.className = 'status status-success';
                status.innerHTML = '<i class="fas fa-play-circle"></i> Running';
            }
        } else {
            if (startBtn) startBtn.style.display = 'inline-flex';
            if (stopBtn) stopBtn.style.display = 'none';
            if (status) {
                status.className = 'status status-warning';
                status.innerHTML = '<i class="fas fa-pause-circle"></i> Stopped';
            }
        }
    }

    showProgress(message, percentage) {
        let progressContainer = document.getElementById('progressContainer');
        
        if (!progressContainer) {
            progressContainer = document.createElement('div');
            progressContainer.id = 'progressContainer';
            progressContainer.className = 'alert alert-info';
            progressContainer.innerHTML = `
                <div class="d-flex align-items-center">
                    <div class="spinner me-2"></div>
                    <div class="flex-grow-1">
                        <div id="progressMessage">${message}</div>
                        <div class="progress mt-2">
                            <div id="progressBar" class="progress-bar" style="width: ${percentage}%"></div>
                        </div>
                    </div>
                </div>
            `;
            
            const container = document.querySelector('.container');
            if (container) {
                container.insertBefore(progressContainer, container.firstChild);
            }
        } else {
            document.getElementById('progressMessage').textContent = message;
            document.getElementById('progressBar').style.width = `${percentage}%`;
        }
    }

    hideProgress() {
        const progressContainer = document.getElementById('progressContainer');
        if (progressContainer) {
            progressContainer.remove();
        }
    }

    showAlert(type, message) {
        // Remove existing alerts
        const existingAlerts = document.querySelectorAll('.alert:not(#progressContainer)');
        existingAlerts.forEach(alert => alert.remove());

        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-dismissible fade show`;
        alert.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

        const container = document.querySelector('.container');
        if (container) {
            container.insertBefore(alert, container.firstChild);
        }

        // Auto-dismiss success alerts
        if (type === 'success') {
            setTimeout(() => {
                if (alert.parentNode) {
                    alert.remove();
                }
            }, 5000);
        }
    }

    updateUI() {
        // Update scheduler status on page load
        const schedulerStatus = document.getElementById('schedulerStatus');
        if (schedulerStatus) {
            const isRunning = schedulerStatus.textContent.includes('Running');
            this.schedulerRunning = isRunning;
            this.updateSchedulerUI();
        }

        // Add loading states to buttons
        document.querySelectorAll('.btn').forEach(btn => {
            btn.addEventListener('click', function() {
                if (!this.disabled && !this.classList.contains('btn-outline-primary')) {
                    const originalText = this.innerHTML;
                    this.disabled = true;
                    this.innerHTML = '<span class="spinner"></span> Loading...';
                    
                    setTimeout(() => {
                        this.disabled = false;
                        this.innerHTML = originalText;
                    }, 2000);
                }
            });
        });
    }
}

// Utility functions
function viewPost(filename) {
    window.open(`/view-post/${filename}`, '_blank');
}

function deletePost(filename) {
    if (window.blogGenerator) {
        window.blogGenerator.deletePost(filename);
    }
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        blogGenerator.showAlert('success', 'Copied to clipboard!');
    }).catch(() => {
        blogGenerator.showAlert('danger', 'Failed to copy to clipboard');
    });
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.blogGenerator = new BlogGenerator();
    
    // Add tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Add smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Add keyboard shortcuts (removed auto-refresh to prevent constant page reload)
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey || e.metaKey) {
            switch(e.key) {
                case 'g':
                    e.preventDefault();
                    document.getElementById('generateContent')?.click();
                    break;
                case 'e':
                    e.preventDefault();
                    document.getElementById('exportSite')?.click();
                    break;
                // Removed 'r' case to prevent automatic refresh
            }
        }
    });
});

// Service worker removed to avoid 404 errors in development
