// Admin Panel JavaScript
class AdminPanel {
    constructor() {
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.loadPosts();
        this.loadStats();
        this.checkSchedulerStatus();
    }
    
    bindEvents() {
        // Generate Content
        document.getElementById('generateBtn').addEventListener('click', () => {
            this.generateContent();
        });
        
        // Scheduler Controls
        document.getElementById('startSchedulerBtn').addEventListener('click', () => {
            this.startScheduler();
        });
        
        document.getElementById('stopSchedulerBtn').addEventListener('click', () => {
            this.stopScheduler();
        });
        
        // Export Site
        document.getElementById('exportBtn').addEventListener('click', () => {
            this.exportSite();
        });
        
        // Tab switching
        document.querySelectorAll('[data-bs-toggle="tab"]').forEach(tab => {
            tab.addEventListener('shown.bs.tab', (e) => {
                const target = e.target.getAttribute('href');
                if (target === '#posts-tab') {
                    this.loadPosts();
                } else if (target === '#stats-tab') {
                    this.loadStats();
                }
            });
        });
    }
    
    async generateContent() {
        const btn = document.getElementById('generateBtn');
        const language = document.getElementById('language').value;
        const count = parseInt(document.getElementById('postCount').value);
        
        this.updateGenerateButton(true);
        this.showProgress('Generating content...', 0);
        
        try {
            // Simulate progress
            let progress = 0;
            const progressInterval = setInterval(() => {
                progress += Math.random() * 20;
                if (progress > 90) progress = 90;
                this.showProgress(`Generating ${count} posts...`, progress);
            }, 500);
            
            const response = await fetch('/generate-content', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    language: language,
                    count: count
                })
            });
            
            clearInterval(progressInterval);
            const data = await response.json();
            
            if (data.success) {
                this.showProgress('Content generated successfully!', 100);
                setTimeout(() => {
                    this.hideProgress();
                    this.showAlert('success', `Successfully generated ${data.posts.length} blog posts!`);
                    this.loadPosts();
                    this.loadStats();
                }, 1000);
            } else {
                this.hideProgress();
                this.showAlert('danger', `Error: ${data.message}`);
            }
        } catch (error) {
            this.hideProgress();
            this.showAlert('danger', `Network error: ${error.message}`);
        } finally {
            this.updateGenerateButton(false);
        }
    }
    
    async startScheduler() {
        const interval = document.getElementById('scheduleInterval').value;
        const posts = document.getElementById('schedulePosts').value;
        
        try {
            const response = await fetch('/start-scheduler', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    interval: parseFloat(interval), // Support decimal hours for unlimited mode
                    posts: parseInt(posts)
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                const intervalFloat = parseFloat(interval);
                if (intervalFloat === 0.5) {
                    this.showAlert('success', '🚀 UNLIMITED SCHEDULER STARTED! Will generate 15-25 posts every 30 minutes!');
                } else {
                    this.showAlert('success', 'Scheduler started successfully!');
                }
                this.updateSchedulerUI(true);
            } else {
                this.showAlert('danger', `Error: ${data.message}`);
            }
        } catch (error) {
            this.showAlert('danger', `Network error: ${error.message}`);
        }
    }
    
    async stopScheduler() {
        try {
            const response = await fetch('/stop-scheduler', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.showAlert('info', 'Scheduler stopped successfully!');
                this.updateSchedulerUI(false);
            } else {
                this.showAlert('danger', `Error: ${data.message}`);
            }
        } catch (error) {
            this.showAlert('danger', `Network error: ${error.message}`);
        }
    }
    
    async exportSite() {
        const btn = document.getElementById('exportBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Exporting...';
        
        try {
            const response = await fetch('/export-site');
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `sakmpar-blog-${new Date().toISOString().split('T')[0]}.zip`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
                
                this.showAlert('success', 'Site exported successfully!');
            } else {
                this.showAlert('danger', 'Error exporting site!');
            }
        } catch (error) {
            this.showAlert('danger', `Export error: ${error.message}`);
        } finally {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-file-archive me-2"></i>Export as ZIP';
        }
    }
    
    async loadPosts() {
        const container = document.getElementById('postsList');
        container.innerHTML = '<div class="text-center"><div class="spinner-border" role="status"></div></div>';
        
        try {
            const response = await fetch('/api/posts');
            const data = await response.json();
            
            if (data.success && data.posts.length > 0) {
                container.innerHTML = '';
                data.posts.forEach(post => {
                    const postElement = this.createPostElement(post);
                    container.appendChild(postElement);
                });
            } else {
                container.innerHTML = `
                    <div class="text-center p-4">
                        <i class="fas fa-file-alt fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No posts found</h5>
                        <p class="text-muted">Generate some content to get started!</p>
                    </div>
                `;
            }
        } catch (error) {
            container.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Error loading posts: ${error.message}
                </div>
            `;
        }
    }
    
    createPostElement(post) {
        const div = document.createElement('div');
        div.className = 'post-item fade-in';
        div.innerHTML = `
            <div class="d-flex justify-content-between align-items-start">
                <div class="flex-grow-1">
                    <h6 class="post-title">${post.title}</h6>
                    <div class="post-meta">
                        <i class="fas fa-file me-1"></i>${post.filename} | 
                        <i class="fas fa-clock me-1"></i>${post.modified || 'Just now'}
                    </div>
                </div>
                <div class="post-actions">
                    <a href="/view-post/${post.filename}" target="_blank" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-eye me-1"></i>View
                    </a>
                    <button class="btn btn-sm btn-outline-danger" onclick="adminPanel.deletePost('${post.filename}')">
                        <i class="fas fa-trash me-1"></i>Delete
                    </button>
                </div>
            </div>
        `;
        return div;
    }
    
    async deletePost(filename) {
        if (!confirm('Are you sure you want to delete this post?')) return;
        
        try {
            const response = await fetch(`/delete-post/${filename}`, {
                method: 'DELETE'
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.showAlert('success', 'Post deleted successfully!');
                this.loadPosts();
                this.loadStats();
            } else {
                this.showAlert('danger', `Error: ${data.message}`);
            }
        } catch (error) {
            this.showAlert('danger', `Error deleting post: ${error.message}`);
        }
    }
    
    async loadStats() {
        try {
            const response = await fetch('/api/stats');
            const data = await response.json();
            
            if (data.success) {
                document.getElementById('totalPosts').textContent = data.stats.total_posts || 0;
                document.getElementById('todayPosts').textContent = data.stats.today_posts || 0;
                document.getElementById('totalViews').textContent = data.stats.total_views || '-';
                document.getElementById('schedulerStatus2').textContent = data.stats.scheduler_running ? 'ON' : 'OFF';
            }
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }
    
    async checkSchedulerStatus() {
        try {
            const response = await fetch('/api/scheduler-status');
            const data = await response.json();
            
            if (data.success) {
                this.updateSchedulerUI(data.status.running);
            }
        } catch (error) {
            console.error('Error checking scheduler status:', error);
        }
    }
    
    updateGenerateButton(isLoading) {
        const btn = document.getElementById('generateBtn');
        if (isLoading) {
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generating...';
        } else {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-magic me-2"></i>Generate Blog Posts';
        }
    }
    
    updateSchedulerUI(isRunning) {
        const state = document.getElementById('schedulerState');
        const startBtn = document.getElementById('startSchedulerBtn');
        const stopBtn = document.getElementById('stopSchedulerBtn');
        
        if (isRunning) {
            state.textContent = 'running';
            state.parentElement.className = 'alert alert-success';
            startBtn.disabled = true;
            stopBtn.disabled = false;
        } else {
            state.textContent = 'stopped';
            state.parentElement.className = 'alert alert-info';
            startBtn.disabled = false;
            stopBtn.disabled = true;
        }
    }
    
    showProgress(message, percentage) {
        const progressContainer = document.getElementById('progressBar');
        const progressBar = progressContainer.querySelector('.progress-bar');
        const progressText = document.getElementById('progressText');
        
        progressContainer.style.display = 'block';
        progressBar.style.width = `${percentage}%`;
        progressText.textContent = message;
    }
    
    hideProgress() {
        document.getElementById('progressBar').style.display = 'none';
    }
    
    showAlert(type, message) {
        const container = document.getElementById('alertContainer');
        const alertId = 'alert-' + Date.now();
        
        const alertHtml = `
            <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show alert-floating" role="alert">
                <i class="fas fa-${this.getAlertIcon(type)} me-2"></i>
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        container.insertAdjacentHTML('beforeend', alertHtml);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            const alert = document.getElementById(alertId);
            if (alert) {
                alert.remove();
            }
        }, 5000);
    }
    
    getAlertIcon(type) {
        const icons = {
            'success': 'check-circle',
            'danger': 'exclamation-circle',
            'warning': 'exclamation-triangle',
            'info': 'info-circle'
        };
        return icons[type] || 'info-circle';
    }
}

// Initialize admin panel
let adminPanel;
document.addEventListener('DOMContentLoaded', () => {
    adminPanel = new AdminPanel();
});

// Global functions for inline event handlers
function viewPost(filename) {
    window.open(`/view-post/${filename}`, '_blank');
}

function deletePost(filename) {
    adminPanel.deletePost(filename);
}